package org.sabirov3312_cwork;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExportToXML {

    private Connection connection;

    public ExportToXML(Connection connection) {
        this.connection = connection;
    }

    public void export() {
        String filePath = show();

        if (filePath != null) {
            try {
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

                Document doc = docBuilder.newDocument();
                Element rootElement = doc.createElement("BusPark");
                doc.appendChild(rootElement);

                Element driversElement = doc.createElement("Drivers");
                rootElement.appendChild(driversElement);
                exportDrivers(doc, driversElement);

                Element routesElement = doc.createElement("Routes");
                rootElement.appendChild(routesElement);
                exportRoutes(doc, routesElement);

                Element schedulesElement = doc.createElement("Schedules");
                rootElement.appendChild(schedulesElement);
                exportSchedules(doc, schedulesElement);

                writeDocumentToFile(doc, filePath);

                JOptionPane.showMessageDialog(null, "Данные успешно экспортированы в файл:\n" + filePath, "Экспорт завершен", JOptionPane.INFORMATION_MESSAGE);
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
        }
    }

    private String show() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Выберите место для сохранения файла");

        fileChooser.setFileFilter(new FileNameExtensionFilter("XML files", "xml"));

        int result = fileChooser.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();

            if (!filePath.endsWith(".xml")) {
                filePath += ".xml";
            }
            return filePath;
        }
        return null;
    }

    private void exportDrivers(Document doc, Element parentElement) {
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Drivers")) {

            while (rs.next()) {
                Element driver = doc.createElement("Driver");
                parentElement.appendChild(driver);

                createElement(doc, driver, "Name", rs.getString("Names"));
                createElement(doc, driver, "Experience", String.valueOf(rs.getInt("Experience")));
                createElement(doc, driver, "Category", rs.getString("Category"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportRoutes(Document doc, Element parentElement) {
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Routes")) {

            while (rs.next()) {
                Element route = doc.createElement("Route");
                parentElement.appendChild(route);

                createElement(doc, route, "RouteNumber", rs.getString("RouteNumber"));
                createElement(doc, route, "StartPoint", rs.getString("StartPoint"));
                createElement(doc, route, "EndPoint", rs.getString("EndPoint"));
                createElement(doc, route, "StartTime", formatTime(rs.getString("StartTime")));
                createElement(doc, route, "EndTime", formatTime(rs.getString("EndTime")));
                createElement(doc, route, "Interval", rs.getString("Interval"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportSchedules(Document doc, Element parentElement) {
        String query = "SELECT s.BusNumber, s.DepartureTime, s.ArrivalTime, s.ActualDepartureTime, s.ActualArrivalTime, s.Violations, r.RouteNumber, d.Names AS DriverName FROM Schedule s JOIN Routes r ON s.RouteID = r.RouteID JOIN Drivers d ON s.DriverID = d.DriverID";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Element schedule = doc.createElement("Schedule");
                parentElement.appendChild(schedule);

                createElement(doc, schedule, "RouteNumber", rs.getString("RouteNumber")); // Номер маршрута
                createElement(doc, schedule, "DriverName", rs.getString("DriverName"));   // ФИО водителя
                createElement(doc, schedule, "BusNumber", rs.getString("BusNumber"));
                createElement(doc, schedule, "DepartureTime", formatTime(rs.getString("DepartureTime")));
                createElement(doc, schedule, "ArrivalTime", formatTime(rs.getString("ArrivalTime")));
                createElement(doc, schedule, "ActualDepartureTime", formatTime(rs.getString("ActualDepartureTime")));
                createElement(doc, schedule, "ActualArrivalTime", formatTime(rs.getString("ActualArrivalTime")));
                createElement(doc, schedule, "Violations", rs.getString("Violations"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void createElement(Document doc, Element parent, String tagName, String value) {
        Element element = doc.createElement(tagName);
        element.appendChild(doc.createTextNode(value));
        parent.appendChild(element);
    }

    private void writeDocumentToFile(Document doc, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            javax.xml.transform.Transformer transformer = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
            transformer.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(writer));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String formatTime(String time) {
        try {
            SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
            SimpleDateFormat targetFormat = new SimpleDateFormat("HH:mm");
            Date date = originalFormat.parse(time);
            return targetFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return time;
        }
    }
}
