package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteRoute {

    private final Connection connection;

    public DeleteRoute(Connection connection) {
        this.connection = connection;
    }

    public void deleteRoute(int selectedRow, DefaultTableModel tableModel) {
        String routeNumber = (String) tableModel.getValueAt(selectedRow, 0); // Получаем номер маршрута

        if (has(routeNumber)) {
            JOptionPane.showMessageDialog(null, "Невозможно удалить маршрут, так как есть записи в расписании с его участием.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int result = JOptionPane.showOptionDialog(null, "Вы точно хотите удалить маршрут: " + routeNumber + "?", "Подтверждение удаления", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Да", "Нет"}, "Нет");

        if (result == 0) {
            String query = "DELETE FROM Routes WHERE RouteNumber = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, routeNumber);
                stmt.executeUpdate();
                tableModel.removeRow(selectedRow);
                JOptionPane.showMessageDialog(null, "Маршрут успешно удален!");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ошибка при удалении маршрута: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean has(String routeNumber) {
        String query = "SELECT COUNT(*) AS count FROM Schedule s JOIN Routes r ON s.RouteID = r.RouteID WHERE r.RouteNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, routeNumber);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при проверке данных расписаний: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
}
