package org.sabirov3312_cwork;

import org.w3c.dom.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ImportFromXML {

    private final Connection connection;

    public ImportFromXML(Connection connection) {
        this.connection = connection;
    }

    public void importData() {
        File xmlFile = chooseFile();
        if (xmlFile != null) {
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(xmlFile);
                doc.getDocumentElement().normalize();

                importDrivers(doc);
                importRoutes(doc);
                importSchedules(doc);

                JOptionPane.showMessageDialog(null, "Данные успешно загружены:\n" + xmlFile, "Импорт завершен", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Вы не выбрали файл для импорта!", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private File chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Выберите XML файл");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("XML Files", "xml"));

        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        }
        return null;
    }

    private void importDrivers(Document doc) {
        try {
            NodeList driverNodes = doc.getElementsByTagName("Driver");
            String getMaxOrderIndexSql = "SELECT COALESCE(MAX(orderindex), 0) FROM Drivers";
            String insertDriverSql = "INSERT INTO Drivers (Names, Experience, Category, orderindex) VALUES (?, ?, ?, ?)";
            String checkDriverExistsSql = "SELECT COUNT(*) FROM Drivers WHERE Names = ? AND Category = ?";

            PreparedStatement getMaxOrderIndexStmt = connection.prepareStatement(getMaxOrderIndexSql);
            ResultSet rs = getMaxOrderIndexStmt.executeQuery();
            int currentMaxOrderIndex = rs.next() ? rs.getInt(1) : 0;

            PreparedStatement preparedStatement = connection.prepareStatement(insertDriverSql);
            PreparedStatement checkDriverExistsStmt = connection.prepareStatement(checkDriverExistsSql);

            for (int i = 0; i < driverNodes.getLength(); i++) {
                Node driverNode = driverNodes.item(i);
                if (driverNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element driverElement = (Element) driverNode;

                    String name = getTextContent(driverElement, "Name");
                    String experienceStr = getTextContent(driverElement, "Experience");
                    int experience = Integer.parseInt(experienceStr);
                    String category = getTextContent(driverElement, "Category");

                    checkDriverExistsStmt.setString(1, name);
                    checkDriverExistsStmt.setString(2, category);
                    ResultSet resultSet = checkDriverExistsStmt.executeQuery();
                    if (resultSet.next() && resultSet.getInt(1) > 0) { continue; }

                    int newOrderIndex = currentMaxOrderIndex + 1 + i;

                    preparedStatement.setString(1, name);
                    preparedStatement.setInt(2, experience);
                    preparedStatement.setString(3, category);
                    preparedStatement.setInt(4, newOrderIndex);

                    preparedStatement.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void importRoutes(Document doc) {
        try {
            NodeList routeNodes = doc.getElementsByTagName("Route");
            String insertRouteSql = "INSERT INTO Routes (RouteNumber, StartPoint, EndPoint, StartTime, EndTime, Interval, orderindex) VALUES (?, ?, ?, ?, ?, ?, ?)";
            String checkRouteExistsSql = "SELECT COUNT(*) FROM Routes WHERE RouteNumber = ?";
            String getMaxOrderIndexSql = "SELECT COALESCE(MAX(orderindex), 0) FROM Routes";

            PreparedStatement insertRouteStmt = connection.prepareStatement(insertRouteSql);
            PreparedStatement checkRouteExistsStmt = connection.prepareStatement(checkRouteExistsSql);
            PreparedStatement getMaxOrderIndexStmt = connection.prepareStatement(getMaxOrderIndexSql);

            ResultSet resultSet = getMaxOrderIndexStmt.executeQuery();
            int currentMaxOrderIndex = resultSet.next() ? resultSet.getInt(1) : 0;

            for (int i = 0; i < routeNodes.getLength(); i++) {
                Node routeNode = routeNodes.item(i);
                if (routeNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element routeElement = (Element) routeNode;

                    String routeNumberStr = getTextContent(routeElement, "RouteNumber");
                    int routeNumber = Integer.parseInt(routeNumberStr);
                    String startPoint = getTextContent(routeElement, "StartPoint");
                    String endPoint = getTextContent(routeElement, "EndPoint");
                    String startTime = getTextContent(routeElement, "StartTime");
                    String endTime = getTextContent(routeElement, "EndTime");
                    String intervalStr = getTextContent(routeElement, "Interval");
                    int interval = Integer.parseInt(intervalStr);

                    startTime = formatDateTime(startTime);
                    endTime = formatDateTime(endTime);

                    checkRouteExistsStmt.setInt(1, routeNumber);
                    ResultSet checkResultSet = checkRouteExistsStmt.executeQuery();
                    if (checkResultSet.next() && checkResultSet.getInt(1) > 0) {continue;}

                    int newOrderIndex = currentMaxOrderIndex + 1 + i;

                    insertRouteStmt.setInt(1, routeNumber);
                    insertRouteStmt.setString(2, startPoint);
                    insertRouteStmt.setString(3, endPoint);
                    insertRouteStmt.setString(4, startTime);
                    insertRouteStmt.setString(5, endTime);
                    insertRouteStmt.setInt(6, interval);
                    insertRouteStmt.setInt(7, newOrderIndex);

                    insertRouteStmt.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void importSchedules(Document doc) {
        try {
            NodeList scheduleNodes = doc.getElementsByTagName("Schedule");

            String getRouteIdSql = "SELECT RouteID FROM Routes WHERE RouteNumber = ?";
            String getDriverIdSql = "SELECT DriverID FROM Drivers WHERE Names = ?";
            String insertSql = "INSERT INTO Schedule (RouteID, BusNumber, DriverID, DepartureTime, ArrivalTime, ActualDepartureTime, ActualArrivalTime, Violations, orderindex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            String checkSql = "SELECT COUNT(*) FROM Schedule WHERE RouteID = ? AND DepartureTime = ? AND BusNumber = ? AND DriverID = ? AND ArrivalTime = ? AND ActualDepartureTime = ? AND ActualArrivalTime = ? AND Violations = ?";
            String getMaxOrderIndexSql = "SELECT COALESCE(MAX(orderindex), 0) FROM Schedule";

            PreparedStatement getRouteIdStmt = connection.prepareStatement(getRouteIdSql);
            PreparedStatement getDriverIdStmt = connection.prepareStatement(getDriverIdSql);
            PreparedStatement insertStmt = connection.prepareStatement(insertSql);
            PreparedStatement checkStmt = connection.prepareStatement(checkSql);
            PreparedStatement getMaxOrderIndexStmt = connection.prepareStatement(getMaxOrderIndexSql);

            ResultSet resultSet = getMaxOrderIndexStmt.executeQuery();
            int currentMaxOrderIndex = resultSet.next() ? resultSet.getInt(1) : 0;

            for (int i = 0; i < scheduleNodes.getLength(); i++) {
                Node scheduleNode = scheduleNodes.item(i);
                if (scheduleNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element scheduleElement = (Element) scheduleNode;

                    String routeNumber = getTextContent(scheduleElement, "RouteNumber");
                    String driverName = getTextContent(scheduleElement, "DriverName");
                    String busNumberStr = getTextContent(scheduleElement, "BusNumber");
                    int busNumber = Integer.parseInt(busNumberStr);
                    String departureTime = formatDateTime(getTextContent(scheduleElement, "DepartureTime"));
                    String arrivalTime = formatDateTime(getTextContent(scheduleElement, "ArrivalTime"));
                    String actualDepartureTime = formatDateTime(getTextContent(scheduleElement, "ActualDepartureTime"));
                    String actualArrivalTime = formatDateTime(getTextContent(scheduleElement, "ActualArrivalTime"));
                    String violations = getTextContent(scheduleElement, "Violations");

                    getRouteIdStmt.setString(1, routeNumber);
                    ResultSet routeResultSet = getRouteIdStmt.executeQuery();
                    if (!routeResultSet.next()) {continue;}
                    int routeID = routeResultSet.getInt("RouteID");

                    getDriverIdStmt.setString(1, driverName);
                    ResultSet driverResultSet = getDriverIdStmt.executeQuery();
                    if (!driverResultSet.next()) {continue;}
                    int driverID = driverResultSet.getInt("DriverID");

                    checkStmt.setInt(1, routeID);
                    checkStmt.setString(2, departureTime);
                    checkStmt.setInt(3, busNumber);
                    checkStmt.setInt(4, driverID);
                    checkStmt.setString(5, arrivalTime);
                    checkStmt.setString(6, actualDepartureTime);
                    checkStmt.setString(7, actualArrivalTime);
                    checkStmt.setString(8, violations);
                    resultSet = checkStmt.executeQuery();
                    if (resultSet.next() && resultSet.getInt(1) > 0) {continue;}

                    int newOrderIndex = currentMaxOrderIndex + 1 + i;

                    insertStmt.setInt(1, routeID);
                    insertStmt.setInt(2, busNumber);
                    insertStmt.setInt(3, driverID);
                    insertStmt.setString(4, departureTime);
                    insertStmt.setString(5, arrivalTime);
                    insertStmt.setString(6, actualDepartureTime);
                    insertStmt.setString(7, actualArrivalTime);
                    insertStmt.setString(8, violations);
                    insertStmt.setInt(9, newOrderIndex);

                    insertStmt.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String formatDateTime(String time) {
        if (time != null && time.length() == 5) {
            return "1899-12-30 " + time + ":00.0";
        }
        return "1899-12-30 " + time;
    }

    private String getTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            Node node = nodeList.item(0);
            if (node != null) {
                return node.getTextContent();
            }
        }
        return null;
    }
}
