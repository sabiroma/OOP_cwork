package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class AddSchedule {

    private final Connection connection;

    public AddSchedule(Connection connection) {
        this.connection = connection;
    }

    public void showAddSchedule(JFrame frame, DefaultTableModel tableModel) {
        JPanel panel = new JPanel(new GridLayout(8, 2));

        JComboBox<String> routeNumberComboBox = new JComboBox<>(getRouteNumbers().toArray(new String[0]));
        routeNumberComboBox.setSelectedIndex(-1);
        JComboBox<String> driverNameComboBox = new JComboBox<>(getDriverNames().toArray(new String[0]));
        driverNameComboBox.setSelectedIndex(-1);

        JTextField busNumberField = new JTextField(20);
        JTextField departureTimeField = new JTextField(20);
        JTextField arrivalTimeField = new JTextField(20);
        JTextField actualDepartureTimeField = new JTextField(20);
        JTextField actualArrivalTimeField = new JTextField(20);
        JTextField violationsField = new JTextField(20);

        panel.add(new JLabel("Номер маршрута: "));
        panel.add(routeNumberComboBox);
        panel.add(new JLabel("ФИО водителя: "));
        panel.add(driverNameComboBox);
        panel.add(new JLabel("Номер автобуса: "));
        panel.add(busNumberField);
        panel.add(new JLabel("Время отправления: "));
        panel.add(departureTimeField);
        panel.add(new JLabel("Время прибытия: "));
        panel.add(arrivalTimeField);
        panel.add(new JLabel("Факт. время отправления: "));
        panel.add(actualDepartureTimeField);
        panel.add(new JLabel("Факт. время прибытия: "));
        panel.add(actualArrivalTimeField);
        panel.add(new JLabel("Нарушения: "));
        panel.add(violationsField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Добавить расписание", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            if (routeNumberComboBox.getSelectedIndex() == -1 || driverNameComboBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите номер маршрута и ФИО водителя.", "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String routeNumber = (String) routeNumberComboBox.getSelectedItem();
            String driverName = (String) driverNameComboBox.getSelectedItem();
            String busNumber = busNumberField.getText();
            String departureTime = departureTimeField.getText();
            String arrivalTime = arrivalTimeField.getText();
            String actualDepartureTime = actualDepartureTimeField.getText();
            String actualArrivalTime = actualArrivalTimeField.getText();
            String violations = violationsField.getText();

            add(routeNumber, driverName, busNumber, departureTime, arrivalTime, actualDepartureTime, actualArrivalTime, violations);
            loadSchedules(tableModel);

            JOptionPane.showMessageDialog(frame, "Расписание успешно добавлено!");
        }
    }

    private java.util.List<String> getRouteNumbers() {
        java.util.List<String> routeNumbers = new ArrayList<>();
        String query = "SELECT RouteNumber FROM Routes";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            while (rs.next()) {
                routeNumbers.add(rs.getString("RouteNumber"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке номеров маршрутов: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }

        return routeNumbers;
    }

    private java.util.List<String> getDriverNames() {
        List<String> driverNames = new ArrayList<>();
        String query = "SELECT Names FROM Drivers";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            while (rs.next()) {
                driverNames.add(rs.getString("Names"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке ФИО водителей: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }

        return driverNames;
    }

    public void add(String routeNumber, String driverName, String busNumber, String departureTime, String arrivalTime, String actualDepartureTime, String actualArrivalTime, String violations) {
        String maxOrderIndexQuery = "SELECT MAX(OrderIndex) AS maxIndex FROM Schedule";
        String query = "INSERT INTO Schedule (RouteID, DriverID, BusNumber, DepartureTime, ArrivalTime, ActualDepartureTime, ActualArrivalTime, Violations, OrderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            int driverID = getDriverID(driverName);
            int routeID = getRouteID(routeNumber);

            if (driverID == -1 || routeID == -1) {
                JOptionPane.showMessageDialog(null, "Ошибка: не удалось найти ID для водителя или маршрута", "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int newOrderIndex = 1;
            try (PreparedStatement maxOrderStmt = connection.prepareStatement(maxOrderIndexQuery)) {
                ResultSet rs = maxOrderStmt.executeQuery();
                if (rs.next() && rs.getInt("maxIndex") > 0) {
                    newOrderIndex = rs.getInt("maxIndex") + 1;
                }
            }

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            java.sql.Time depTime = new java.sql.Time(timeFormat.parse(departureTime.trim()).getTime());
            java.sql.Time arrTime = new java.sql.Time(timeFormat.parse(arrivalTime.trim()).getTime());
            java.sql.Time actDepTime = new java.sql.Time(timeFormat.parse(actualDepartureTime.trim()).getTime());
            java.sql.Time actArrTime = new java.sql.Time(timeFormat.parse(actualArrivalTime.trim()).getTime());

            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, routeID);
                stmt.setInt(2, driverID);
                stmt.setString(3, busNumber);
                stmt.setTime(4, depTime);
                stmt.setTime(5, arrTime);
                stmt.setTime(6, actDepTime);
                stmt.setTime(7, actArrTime);
                stmt.setString(8, violations);
                stmt.setInt(9, newOrderIndex);

                stmt.executeUpdate();
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Ошибка в формате времени. Используйте HH:mm, например 10:30", "Ошибка", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при добавлении расписания: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public int getDriverID(String driverName) {
        String query = "SELECT DriverID FROM Drivers WHERE Names = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, driverName);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("DriverID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при поиске ID водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return -1;
    }

    public int getRouteID(String routeNumber) {
        String query = "SELECT RouteID FROM Routes WHERE RouteNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, routeNumber);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("RouteID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при поиске ID маршрута: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return -1;
    }

    public void loadSchedules(DefaultTableModel tableModel) {
        try {
            String query = "SELECT s.ScheduleID, r.RouteNumber, d.Names AS DriverName, s.BusNumber, s.DepartureTime, s.ArrivalTime, s.ActualDepartureTime, s.ActualArrivalTime, s.Violations, s.OrderIndex " + "FROM Schedule s " + "JOIN Routes r ON s.RouteID = r.RouteID " + "JOIN Drivers d ON s.DriverID = d.DriverID " + "ORDER BY s.OrderIndex ASC";

            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            while (rs.next()) {
                String departureTime = timeFormat.format(rs.getTime("DepartureTime"));
                String arrivalTime = timeFormat.format(rs.getTime("ArrivalTime"));
                String actualDepartureTime = timeFormat.format(rs.getTime("ActualDepartureTime"));
                String actualArrivalTime = timeFormat.format(rs.getTime("ActualArrivalTime"));

                tableModel.addRow(new Object[]{
                        rs.getString("RouteNumber"),
                        rs.getString("DriverName"),
                        rs.getString("BusNumber"),
                        departureTime,
                        arrivalTime,
                        actualDepartureTime,
                        actualArrivalTime,
                        rs.getString("Violations"),
                        rs.getInt("OrderIndex")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке данных расписаний: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
