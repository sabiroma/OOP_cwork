package org.sabirov3312_cwork;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class mainWindow {

    private JButton driversButton, routesButton, finesButton, selectFileButton;

    public void show() {

        JFrame frame = new JFrame("Главное меню");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 1));

        driversButton = new JButton("Список водителей");
        routesButton = new JButton("Маршруты");
        finesButton = new JButton("График движения");
        selectFileButton = new JButton("Выбор базы данных");

        frame.add(driversButton);
        frame.add(routesButton);
        frame.add(finesButton);
        frame.add(selectFileButton);

        driversButton.addActionListener(e -> {
            frame.dispose();
            DriversWindow driversWindow = new DriversWindow();
            driversWindow.show();
        });

        routesButton.addActionListener(e -> {
            frame.dispose();
            RoutesWindow routesWindow = new RoutesWindow();
            routesWindow.show();
        });

        finesButton.addActionListener(e -> {
            frame.dispose();
            ScheduleWindow scheduleWindow = new ScheduleWindow();
            scheduleWindow.show();
        });

        selectFileButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Выбор базы данных");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Access Database Files", "accdb"));

            int result = fileChooser.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String filePath = selectedFile.getAbsolutePath();

                saveFilePath(filePath);
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void saveFilePath(String filePath) {
        try (FileWriter writer = new FileWriter("dbpath.txt")) {
            writer.write(filePath);
            JOptionPane.showMessageDialog(null, "Путь к базе данных сохранен");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при сохранении пути: " + e.getMessage());
        }
    }
}
