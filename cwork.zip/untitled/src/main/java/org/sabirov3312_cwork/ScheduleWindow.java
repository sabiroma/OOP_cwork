package org.sabirov3312_cwork;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.query.JRXPathQueryExecuterFactory;
import net.sf.jasperreports.view.JasperViewer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.io.File;
import java.sql.Connection;
import java.util.HashMap;

public class ScheduleWindow {

    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel topPanel, filterPanel, tablePanel, leftPanel, rightPanel, saveLoadPanel, menuPanel, headerPanel;
    private JButton addButton, editButton, deleteButton, searchButton, saveButton, loadButton, resetButton, mainMenu, reportButton;
    private JComboBox<String> searchCriteria, changeTable;
    private JTextField searchField;
    private JScrollPane scrollPane;
    private Connection connection;
    private AddSchedule addSchedule;
    private DeleteSchedule deleteSchedule;
    private EditSchedule editSchedule;
    private TableRowSorter<DefaultTableModel> sorter;
    private JButton sortAscButton, sortDescButton;
    private JComboBox<String> sortCriteria;
    private TableSorter tableSorter;
    private TableSearch searchHandler;
    private ExportToXML exportToXML;
    private ImportFromXML importFromXML;

    public void show() {

        frame = new JFrame("График движения");
        frame.setSize(1600, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(false);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screenSize.width - frame.getWidth()) / 2;
        int y = (screenSize.height - frame.getHeight()) / 2;
        frame.setLocation(x, y);

        mainMenu = new JButton("Главное меню");
        menuPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        menuPanel.add(mainMenu);
        menuPanel.add(new JLabel("Таблица: "));
        changeTable = new JComboBox<>(new String[]{"Список водителей", "Маршруты", "График движения"});
        changeTable.setSelectedItem("График движения");
        menuPanel.add(changeTable);

        saveLoadPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        saveButton = new JButton("Сохранить");
        loadButton = new JButton("Загрузить");
        saveLoadPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        saveLoadPanel.add(saveButton);
        saveLoadPanel.add(loadButton);

        tablePanel = new JPanel(new BorderLayout());
        tablePanel.add(menuPanel, BorderLayout.EAST);
        tablePanel.add(saveLoadPanel, BorderLayout.WEST);

        leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addButton = new JButton("Добавить");
        editButton = new JButton("Редактировать");
        deleteButton = new JButton("Удалить");
        leftPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        leftPanel.add(addButton);
        leftPanel.add(editButton);
        leftPanel.add(deleteButton);

        rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        reportButton = new JButton("Создать отчет");
        sortCriteria = new JComboBox<>(new String[]{"Номер маршрута", "ФИО водителя", "Номер автобуса", "Время отправления", "Время прибытия", "Факт. время отправления", "Факт. время прибытия", "Нарушения"});
        sortAscButton = new JButton("По возрастанию ↑");
        sortDescButton = new JButton("По убыванию ↓");
        rightPanel.add(reportButton);
        rightPanel.add(new JLabel("Сортировать: "));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        rightPanel.add(sortCriteria);
        rightPanel.add(sortAscButton);
        rightPanel.add(sortDescButton);

        topPanel = new JPanel(new BorderLayout());
        topPanel.add(leftPanel, BorderLayout.WEST);
        topPanel.add(rightPanel, BorderLayout.EAST);

        headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.add(tablePanel);
        headerPanel.add(topPanel);
        frame.add(headerPanel, BorderLayout.NORTH);

        searchCriteria = new JComboBox<>(new String[]{"Номер маршрута", "ФИО водителя", "Номер автобуса", "Время отправления", "Время прибытия", "Факт. время отправления", "Факт. время прибытия", "Нарушения"});
        searchField = new JTextField(20);
        searchButton = new JButton("Поиск");
        resetButton = new JButton("Показать все записи");

        filterPanel = new JPanel();
        filterPanel.add(new JLabel("Критерий поиска: "));
        filterPanel.add(searchCriteria);
        filterPanel.add(new JLabel("Значение: "));
        filterPanel.add(searchField);
        filterPanel.add(searchButton);
        filterPanel.add(Box.createHorizontalStrut(10));
        filterPanel.add(resetButton);
        frame.add(filterPanel, BorderLayout.SOUTH);

        String[] columns = {"Номер маршрута", "ФИО водителя", "Номер автобуса", "Время отправления", "Время прибытия", "Факт. время отправления", "Факт. время прибытия", "Нарушения"};
        Object[][] data = {};
        tableModel = new DefaultTableModel(data, columns);
        table = new JTable(tableModel);
        scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
        dbDataLoader.loadSchedules();

        DBConnection dbConnection = new DBConnection();
        connection = dbConnection.connect();
        addSchedule = new AddSchedule(connection);
        deleteSchedule = new DeleteSchedule(connection);
        editSchedule = new EditSchedule(connection);
        tableSorter = new TableSorter(connection);
        exportToXML = new ExportToXML(connection);
        importFromXML = new ImportFromXML(connection);

        sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        searchHandler = new TableSearch(frame, table, sorter);

        Listeners();

        frame.setVisible(true);
    }

    private void Listeners() {

        addButton.addActionListener(e -> {
            addSchedule.showAddSchedule(frame, tableModel);
        });

        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int modelRow = table.convertRowIndexToModel(selectedRow);
                editSchedule.show(frame, tableModel, modelRow);
            } else {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите строку для редактирования", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int modelRow = table.convertRowIndexToModel(selectedRow);
                deleteSchedule.deleteSchedule(modelRow, tableModel);
            } else {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите строку для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        saveButton.addActionListener(e -> {
            exportToXML.export();
        });

        loadButton.addActionListener(e -> {
            importFromXML.importData();
            tableModel.setRowCount(0);
            DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
            dbDataLoader.loadSchedules();
        });

        mainMenu.addActionListener(e -> {
            frame.dispose();
            mainWindow mainWindow = new mainWindow();
            mainWindow.show();
        });

        changeTable.addActionListener(e -> {
            windowSwitcher WindowSwitcher = new windowSwitcher(frame, changeTable, getClass().getSimpleName());
            WindowSwitcher.switchWindow();
        });

        sortAscButton.addActionListener(e -> {
            tableSorter.sortSchedules(tableModel, table, sortCriteria.getSelectedIndex(), true);
        });

        sortDescButton.addActionListener(e -> {
            tableSorter.sortSchedules(tableModel, table, sortCriteria.getSelectedIndex(), false);
        });

        searchButton.addActionListener(e -> {
            sorter = new TableRowSorter<>(tableModel);
            table.setRowSorter(sorter);
            searchHandler = new TableSearch(frame, table, sorter);

            String criterion = (String) searchCriteria.getSelectedItem();
            String value = searchField.getText().trim();
            try {
                searchHandler.scheduleSearch(criterion, value);
            } catch (EmptySearchFieldException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Ошибка поиска", JOptionPane.ERROR_MESSAGE);
            }
        });

        resetButton.addActionListener(e -> {
            sorter.setRowFilter(null);
        });

        reportButton.addActionListener(e -> {
            generateReport();
        });
    }

    private void generateReport() {
        try {

            Object[] options = {"PDF", "HTML"};
            int result = JOptionPane.showOptionDialog(frame, "                Выберите формат отчета", "Создание отчета", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (result == JOptionPane.CLOSED_OPTION) { return; }

            String selectedFormat = (String) options[result];

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();

            Element rootElement = doc.createElement("Schedules");
            doc.appendChild(rootElement);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                Element schedule = doc.createElement("Schedule");

                Element routeNumber = doc.createElement("RouteNumber");
                routeNumber.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 0)));
                schedule.appendChild(routeNumber);

                Element driverName = doc.createElement("DriverName");
                driverName.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 1)));
                schedule.appendChild(driverName);

                Element busNumber = doc.createElement("BusNumber");
                busNumber.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 2)));
                schedule.appendChild(busNumber);

                Element departureTime = doc.createElement("DepartureTime");
                departureTime.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 3)));
                schedule.appendChild(departureTime);

                Element arrivalTime = doc.createElement("ArrivalTime");
                arrivalTime.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 4)));
                schedule.appendChild(arrivalTime);

                Element actualDepartureTime = doc.createElement("ActualDepartureTime");
                actualDepartureTime.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 5)));
                schedule.appendChild(actualDepartureTime);

                Element actualArrivalTime = doc.createElement("ActualArrivalTime");
                actualArrivalTime.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 6)));
                schedule.appendChild(actualArrivalTime);

                Element violations = doc.createElement("Violations");
                violations.appendChild(doc.createTextNode((String) tableModel.getValueAt(i, 7)));
                schedule.appendChild(violations);

                rootElement.appendChild(schedule);
            }

            String reportPath = "cwork.jrxml"; // Убедитесь, что этот файл соответствует структуре XML.
            JasperReport jasperReport = JasperCompileManager.compileReport(reportPath);

            HashMap<String, Object> parameters = new HashMap<>();
            parameters.put(JRXPathQueryExecuterFactory.PARAMETER_XML_DATA_DOCUMENT, doc);

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters);

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Сохранить отчет как");
            if ("PDF".equals(selectedFormat)) {
                fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("PDF Files", "pdf"));
            } else {
                fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("HTML Files", "html"));
            }

            int userSelection = fileChooser.showSaveDialog(frame);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String filePath = selectedFile.getAbsolutePath();

                if ("PDF".equals(selectedFormat) && !filePath.toLowerCase().endsWith(".pdf")) {
                    filePath += ".pdf";
                } else if ("HTML".equals(selectedFormat) && !filePath.toLowerCase().endsWith(".html")) {
                    filePath += ".html";
                }

                if ("PDF".equals(selectedFormat)) {
                    JasperExportManager.exportReportToPdfFile(jasperPrint, filePath);
                } else {
                    JasperExportManager.exportReportToHtmlFile(jasperPrint, filePath);
                }

                JOptionPane.showMessageDialog(frame, "Отчет успешно создан: " + filePath);
                JasperViewer.viewReport(jasperPrint, false);
            } else {
                JOptionPane.showMessageDialog(frame, "Создание отчета отменено.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Ошибка при создании отчета: " + e.getMessage());
        }
    }


}
