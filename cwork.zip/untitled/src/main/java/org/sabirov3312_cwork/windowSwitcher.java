package org.sabirov3312_cwork;

import javax.swing.*;

public class windowSwitcher {

    private JFrame currentFrame;
    private JComboBox<String> table;
    private String currentWindow;

    public windowSwitcher(JFrame currentFrame, JComboBox<String> table, String currentWindow) {
        this.currentFrame = currentFrame;
        this.table = table;
        this.currentWindow = currentWindow;
    }

    public void switchWindow() {
        String select = (String) table.getSelectedItem();

        if (select.equals("Список водителей") && !currentWindow.equals("DriversWindow")) {
            currentFrame.dispose();
            new DriversWindow().show();
        } else if (select.equals("Маршруты") && !currentWindow.equals("RoutesWindow")) {
            currentFrame.dispose();
            new RoutesWindow().show();
        } else if (select.equals("График движения") && !currentWindow.equals("ScheduleWindow")) {
            currentFrame.dispose();
            new ScheduleWindow().show();
        }
    }
}
