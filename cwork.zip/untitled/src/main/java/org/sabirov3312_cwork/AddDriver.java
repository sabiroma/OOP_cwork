package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddDriver {

    private final Connection connection;

    public AddDriver(Connection connection) {
        this.connection = connection;
    }

    public void showAddDriver(JFrame frame, DefaultTableModel tableModel) {
        JPanel panel = new JPanel(new GridLayout(3, 2));

        JTextField nameField = new JTextField(20);
        JTextField experienceField = new JTextField(20);
        JTextField categoryField = new JTextField(20);

        panel.add(new JLabel("ФИО: "));
        panel.add(nameField);
        panel.add(new JLabel("Стаж работы: "));
        panel.add(experienceField);
        panel.add(new JLabel("Класс: "));
        panel.add(categoryField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Добавить водителя", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                String experience = experienceField.getText();
                String category = categoryField.getText();

                validate(name, experience, category);

                add(name, experience, category);
                loadDrivers(tableModel);
            } catch (InvalidFieldException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void validate(String name, String experience, String category) throws InvalidFieldException {
        if (name.isEmpty() || experience.isEmpty() || category.isEmpty()) {
            throw new InvalidFieldException("Все поля должны быть заполнены.");
        }
    }

    private void add(String name, String experience, String category) {
        String checkQuery = "SELECT COUNT(*) AS count FROM Drivers WHERE Names = ?";
        String maxOrderIndexQuery = "SELECT MAX(OrderIndex) AS maxIndex FROM Drivers";
        String insertQuery = "INSERT INTO Drivers (Names, Experience, Category, OrderIndex) VALUES (?, ?, ?, ?)";

        try {
            try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                checkStmt.setString(1, name);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt("count") > 0) {
                    JOptionPane.showMessageDialog(null, "Ошибка: Водитель с таким именем уже существует!", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            int newOrderIndex = 1;
            try (PreparedStatement maxOrderStmt = connection.prepareStatement(maxOrderIndexQuery)) {
                ResultSet rs = maxOrderStmt.executeQuery();
                if (rs.next() && rs.getInt("maxIndex") > 0) {
                    newOrderIndex = rs.getInt("maxIndex") + 1;
                }
            }

            try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                insertStmt.setString(1, name);
                insertStmt.setString(2, experience);
                insertStmt.setString(3, category);
                insertStmt.setInt(4, newOrderIndex);
                insertStmt.executeUpdate();

                JOptionPane.showMessageDialog(null, "Водитель успешно добавлен!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при добавлении водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDrivers(DefaultTableModel tableModel) {
        try {
            String query = "SELECT Names, Experience, Category, OrderIndex FROM Drivers ORDER BY OrderIndex ASC";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);

            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getString("Names"), rs.getString("Experience"), rs.getString("Category"), rs.getInt("OrderIndex")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке данных водителей: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
