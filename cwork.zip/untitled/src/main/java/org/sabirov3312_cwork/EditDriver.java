package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EditDriver {

    private final Connection connection;

    public EditDriver(Connection connection) {
        this.connection = connection;
    }

    public void show(JFrame frame, DefaultTableModel tableModel, int selectedRow) {
        String selectedName = (String) tableModel.getValueAt(selectedRow, 0);
        String selectedExperience = (String) tableModel.getValueAt(selectedRow, 1);
        String selectedCategory = (String) tableModel.getValueAt(selectedRow, 2);

        JPanel panel = new JPanel(new GridLayout(3, 2));

        JTextField nameField = new JTextField(selectedName, 20);
        JTextField experienceField = new JTextField(selectedExperience, 20);
        JTextField categoryField = new JTextField(selectedCategory, 20);

        panel.add(new JLabel("ФИО: "));
        panel.add(nameField);
        panel.add(new JLabel("Стаж работы: "));
        panel.add(experienceField);
        panel.add(new JLabel("Класс: "));
        panel.add(categoryField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Редактировать данные водителя", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String newName = nameField.getText();
            String newExperience = experienceField.getText();
            String newCategory = categoryField.getText();

            try {
                validate(newName, newExperience, newCategory, selectedName);

                edit(selectedName, newName, newExperience, newCategory);
                loadDrivers(tableModel);
                tableModel.setRowCount(0);
                DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
                dbDataLoader.loadDrivers();
                JOptionPane.showMessageDialog(null, "Данные водителя успешно обновлены!");
            } catch (InvalidFieldException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void validate(String name, String experience, String category, String oldName) throws InvalidFieldException {
        if (name.isEmpty() || experience.isEmpty() || category.isEmpty()) {
            throw new InvalidFieldException("Все поля должны быть заполнены.");
        }

        String checkQuery = "SELECT COUNT(*) AS count FROM Drivers WHERE Names = ? AND Names != ?";
        try (PreparedStatement stmt = connection.prepareStatement(checkQuery)) {
            stmt.setString(1, name);
            stmt.setString(2, oldName);

            var rs = stmt.executeQuery();
            if (rs.next() && rs.getInt("count") > 0) {
                throw new InvalidFieldException("Ошибка: Водитель с таким именем уже существует.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при проверке имени водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void edit(String oldName, String newName, String newExperience, String newCategory) {
        String query = "UPDATE Drivers SET Names = ?, Experience = ?, Category = ? WHERE Names = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, newName);
            stmt.setString(2, newExperience);
            stmt.setString(3, newCategory);
            stmt.setString(4, oldName);

            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при обновлении данных водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDrivers(DefaultTableModel tableModel) {
        try {
            String query = "SELECT Names, Experience, Category FROM Drivers";
            PreparedStatement stmt = connection.prepareStatement(query);
            var rs = stmt.executeQuery();

            tableModel.setRowCount(0);

            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getString("Names"), rs.getString("Experience"), rs.getString("Category")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке данных водителей: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
