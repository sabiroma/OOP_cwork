package org.sabirov3312_cwork;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private Connection connection;

    public Connection connect() {
        String dbPath = readPath();
        if (dbPath == null || dbPath.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Выберите базу данных", "Ошибка", JOptionPane.ERROR_MESSAGE);
            mainWindow mainWindow = new mainWindow();
            mainWindow.show();
            return null;
        }

        File dbFile = new File(dbPath);
        if (!dbFile.exists() || !dbFile.isFile()) {
            JOptionPane.showMessageDialog(null, "База данных по выбранному пути не найдена", "Ошибка", JOptionPane.ERROR_MESSAGE);
            mainWindow mainWindow = new mainWindow();
            mainWindow.show();
            return null;
        }

        try {
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            connection = DriverManager.getConnection(dbUrl);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка подключения: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return connection;
    }

    private String readPath() {
        String filePath = null;
        try (BufferedReader reader = new BufferedReader(new FileReader("dbpath.txt"))) {
            filePath = reader.readLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при чтении пути из файла: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return filePath;
    }
}
