package org.sabirov3312_cwork;

public class main {
    public static void main(String[] args) {

        mainWindow mainWindow = new mainWindow();
        mainWindow.show();
    }
}
