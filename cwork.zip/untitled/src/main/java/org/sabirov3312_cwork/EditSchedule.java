package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class EditSchedule {

    private final Connection connection;

    public EditSchedule(Connection connection) {
        this.connection = connection;
    }

    public void show(JFrame frame, DefaultTableModel tableModel, int selectedRow) {
        String currentRouteNumber = (String) tableModel.getValueAt(selectedRow, 0);
        String currentDriverName = (String) tableModel.getValueAt(selectedRow, 1);
        String currentBusNumber = (String) tableModel.getValueAt(selectedRow, 2);
        String currentDepartureTime = (String) tableModel.getValueAt(selectedRow, 3);
        String currentArrivalTime = (String) tableModel.getValueAt(selectedRow, 4);
        String currentActualDepartureTime = (String) tableModel.getValueAt(selectedRow, 5);
        String currentActualArrivalTime = (String) tableModel.getValueAt(selectedRow, 6);
        String currentViolations = (String) tableModel.getValueAt(selectedRow, 7);

        JPanel panel = new JPanel(new GridLayout(8, 2));

        JComboBox<String> routeNumberComboBox = new JComboBox<>(getRouteNumbers().toArray(new String[0]));
        routeNumberComboBox.setSelectedItem(currentRouteNumber);
        JComboBox<String> driverNameComboBox = new JComboBox<>(getDriverNames().toArray(new String[0]));
        driverNameComboBox.setSelectedItem(currentDriverName);

        JTextField busNumberField = new JTextField(currentBusNumber, 20);
        JTextField departureTimeField = new JTextField(currentDepartureTime, 20);
        JTextField arrivalTimeField = new JTextField(currentArrivalTime, 20);
        JTextField actualDepartureTimeField = new JTextField(currentActualDepartureTime, 20);
        JTextField actualArrivalTimeField = new JTextField(currentActualArrivalTime, 20);
        JTextField violationsField = new JTextField(currentViolations, 20);

        panel.add(new JLabel("Номер маршрута: "));
        panel.add(routeNumberComboBox);
        panel.add(new JLabel("ФИО водителя: "));
        panel.add(driverNameComboBox);
        panel.add(new JLabel("Номер автобуса: "));
        panel.add(busNumberField);
        panel.add(new JLabel("Время отправления: "));
        panel.add(departureTimeField);
        panel.add(new JLabel("Время прибытия: "));
        panel.add(arrivalTimeField);
        panel.add(new JLabel("Факт. время отправления: "));
        panel.add(actualDepartureTimeField);
        panel.add(new JLabel("Факт. время прибытия: "));
        panel.add(actualArrivalTimeField);
        panel.add(new JLabel("Нарушения: "));
        panel.add(violationsField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Редактировать расписание", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            if (routeNumberComboBox.getSelectedIndex() == -1 || driverNameComboBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите номер маршрута и ФИО водителя.", "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String newRouteNumber = (String) routeNumberComboBox.getSelectedItem();
            String newDriverName = (String) driverNameComboBox.getSelectedItem();
            String newBusNumber = busNumberField.getText();
            String newDepartureTime = departureTimeField.getText();
            String newArrivalTime = arrivalTimeField.getText();
            String newActualDepartureTime = actualDepartureTimeField.getText();
            String newActualArrivalTime = actualArrivalTimeField.getText();
            String newViolations = violationsField.getText();

            try {
                validate(newDepartureTime, newArrivalTime, newActualDepartureTime, newActualArrivalTime);
                edit(currentRouteNumber, currentDriverName, newRouteNumber, newDriverName, newBusNumber, newDepartureTime, newArrivalTime, newActualDepartureTime, newActualArrivalTime, newViolations);
                loadSchedules(tableModel);
                tableModel.setRowCount(0);
                DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
                dbDataLoader.loadSchedules();
                JOptionPane.showMessageDialog(frame, "Расписание успешно обновлено!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame, e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void validate(String departureTime, String arrivalTime, String actualDepartureTime, String actualArrivalTime) throws ParseException {
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.parse(departureTime.trim());
        timeFormat.parse(arrivalTime.trim());
        timeFormat.parse(actualDepartureTime.trim());
        timeFormat.parse(actualArrivalTime.trim());
    }

    private void edit(String oldRouteNumber, String oldDriverName, String newRouteNumber, String newDriverName, String busNumber, String departureTime, String arrivalTime, String actualDepartureTime, String actualArrivalTime, String violations) throws SQLException, ParseException {
        String query = "UPDATE Schedule SET RouteID = (SELECT RouteID FROM Routes WHERE RouteNumber = ?), DriverID = (SELECT DriverID FROM Drivers WHERE Names = ?), BusNumber = ?, DepartureTime = ?, ArrivalTime = ?, ActualDepartureTime = ?, ActualArrivalTime = ?, Violations = ? WHERE RouteID = (SELECT RouteID FROM Routes WHERE RouteNumber = ?) AND DriverID = (SELECT DriverID FROM Drivers WHERE Names = ?)";
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, newRouteNumber);
            stmt.setString(2, newDriverName);
            stmt.setString(3, busNumber);
            stmt.setTime(4, new java.sql.Time(timeFormat.parse(departureTime).getTime()));
            stmt.setTime(5, new java.sql.Time(timeFormat.parse(arrivalTime).getTime()));
            stmt.setTime(6, new java.sql.Time(timeFormat.parse(actualDepartureTime).getTime()));
            stmt.setTime(7, new java.sql.Time(timeFormat.parse(actualArrivalTime).getTime()));
            stmt.setString(8, violations);
            stmt.setString(9, oldRouteNumber);
            stmt.setString(10, oldDriverName);

            stmt.executeUpdate();
        }
    }

    private List<String> getRouteNumbers() {
        List<String> routeNumbers = new ArrayList<>();
        String query = "SELECT RouteNumber FROM Routes";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            while (rs.next()) {
                routeNumbers.add(rs.getString("RouteNumber"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке номеров маршрутов: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return routeNumbers;
    }

    private List<String> getDriverNames() {
        List<String> driverNames = new ArrayList<>();
        String query = "SELECT Names FROM Drivers";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            while (rs.next()) {
                driverNames.add(rs.getString("Names"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке ФИО водителей: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return driverNames;
    }

    public void loadSchedules(DefaultTableModel tableModel) {
        String query = "SELECT s.ScheduleID, r.RouteNumber, d.Names AS DriverName, s.BusNumber, s.DepartureTime, s.ArrivalTime, s.ActualDepartureTime, s.ActualArrivalTime, s.Violations FROM Schedule s JOIN Routes r ON s.RouteID = r.RouteID JOIN Drivers d ON s.DriverID = d.DriverID";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getString("RouteNumber"), rs.getString("DriverName"), rs.getString("BusNumber"), timeFormat.format(rs.getTime("DepartureTime")), timeFormat.format(rs.getTime("ArrivalTime")), timeFormat.format(rs.getTime("ActualDepartureTime")), timeFormat.format(rs.getTime("ActualArrivalTime")), rs.getString("Violations")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке данных расписаний: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
