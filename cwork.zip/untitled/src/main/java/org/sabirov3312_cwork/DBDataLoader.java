package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;


public class DBDataLoader {

    private JFrame frame;
    private DefaultTableModel tableModel;

    private Connection connection;
    private DBConnection dbConnection;

    public DBDataLoader(JFrame frame, DefaultTableModel tableModel) {
        this.frame = frame;
        this.tableModel = tableModel;
        this.dbConnection = new DBConnection();
        this.connection = dbConnection.connect();
    }

    public void loadDrivers() {
        try {
            String query = "SELECT Names, Experience, Category FROM Drivers ORDER BY OrderIndex ASC";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String name = resultSet.getString("Names");
                String experience = resultSet.getString("Experience");
                String category = resultSet.getString("Category");

                tableModel.addRow(new Object[]{name, experience, category});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Ошибка при загрузке данных о водителях: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadRoutes() {
        try {
            String query = "SELECT r.RouteNumber, r.StartPoint, r.EndPoint, r.StartTime, r.EndTime, r.Interval, r.OrderIndex FROM Routes r ORDER BY r.OrderIndex ASC";

            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            while (resultSet.next()) {
                String routeNumber = resultSet.getString("RouteNumber");
                String startPoint = resultSet.getString("StartPoint");
                String endPoint = resultSet.getString("EndPoint");

                java.sql.Time startTime = resultSet.getTime("StartTime");
                java.sql.Time endTime = resultSet.getTime("EndTime");

                String formattedStartTime = timeFormat.format(startTime);
                String formattedEndTime = timeFormat.format(endTime);

                String interval = resultSet.getString("Interval");

                tableModel.addRow(new Object[]{routeNumber, startPoint, endPoint, formattedStartTime, formattedEndTime, interval});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Ошибка при загрузке данных о маршрутах: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadSchedules() {
        try {
            String query = "SELECT r.RouteNumber, d.Names AS DriverName, s.BusNumber, Format(s.DepartureTime, 'hh:nn') AS DepartureTime, Format(s.ArrivalTime, 'hh:nn') AS ArrivalTime, Format(s.ActualDepartureTime, 'hh:nn') AS ActualDepartureTime, Format(s.ActualArrivalTime, 'hh:nn') AS ActualArrivalTime, s.Violations, s.OrderIndex FROM Schedule s JOIN Drivers d ON s.DriverID = d.DriverID JOIN Routes r ON s.RouteID = r.RouteID ORDER BY s.OrderIndex ASC";

            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String routeNumber = resultSet.getString("RouteNumber");
                String driverName = resultSet.getString("DriverName");
                String busNumber = resultSet.getString("BusNumber");
                String departureTime = resultSet.getString("DepartureTime");
                String arrivalTime = resultSet.getString("ArrivalTime");
                String actualDepartureTime = resultSet.getString("ActualDepartureTime");
                String actualArrivalTime = resultSet.getString("ActualArrivalTime");
                String violations = resultSet.getString("Violations");

                tableModel.addRow(new Object[]{
                        routeNumber, driverName, busNumber, departureTime,
                        arrivalTime, actualDepartureTime, actualArrivalTime, violations
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Ошибка при загрузке данных о расписаниях: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
