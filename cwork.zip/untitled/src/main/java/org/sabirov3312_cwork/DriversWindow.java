package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.table.TableRowSorter;

import java.sql.Connection;

public class DriversWindow {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel topPanel, filterPanel, tablePanel, leftPanel, rightPanel, saveLoadPanel, menuPanel, headerPanel;
    private JButton addButton, editButton, deleteButton, searchButton, saveButton, loadButton, resetButton, mainMenu;
    private JComboBox<String> searchCriteria, changeTable;
    private JTextField searchField;
    private JScrollPane scrollPane;
    private Connection connection;
    private EditDriver editDriver;
    private AddDriver addDriver;
    private DeleteDriver deleteDriver;
    private TableRowSorter<DefaultTableModel> sorter;
    private JButton sortAscButton, sortDescButton;
    private JComboBox<String> sortCriteria;
    private TableSorter tableSorter;
    private TableSearch searchHandler;
    private ExportToXML exportToXML;
    private ImportFromXML importFromXML;

    public void show() {

        frame = new JFrame("Список водителей");
        frame.setSize(1600, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(false);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screenSize.width - frame.getWidth()) / 2;
        int y = (screenSize.height - frame.getHeight()) / 2;
        frame.setLocation(x, y);

        mainMenu = new JButton("Главное меню");
        menuPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        menuPanel.add(mainMenu);
        menuPanel.add(new JLabel("Таблица: "));
        changeTable = new JComboBox<>(new String[]{"Список водителей", "Маршруты", "График движения"});
        changeTable.setSelectedItem("Список водителей");
        menuPanel.add(changeTable);

        saveLoadPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        saveButton = new JButton("Сохранить");
        loadButton = new JButton("Загрузить");
        saveLoadPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        saveLoadPanel.add(saveButton);
        saveLoadPanel.add(loadButton);

        tablePanel = new JPanel(new BorderLayout());
        tablePanel.add(menuPanel, BorderLayout.EAST);
        tablePanel.add(saveLoadPanel, BorderLayout.WEST);

        leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addButton = new JButton("Добавить");
        editButton = new JButton("Редактировать");
        deleteButton = new JButton("Удалить");
        leftPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        leftPanel.add(addButton);
        leftPanel.add(editButton);
        leftPanel.add(deleteButton);

        rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sortCriteria = new JComboBox<>(new String[]{"ФИО водителя", "Стаж работы", "Класс"});
        sortAscButton = new JButton("По возрастанию ↑");
        sortDescButton = new JButton("По убыванию ↓");
        rightPanel.add(new JLabel("Сортировать: "));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        rightPanel.add(sortCriteria);
        rightPanel.add(sortAscButton);
        rightPanel.add(sortDescButton);

        topPanel = new JPanel(new BorderLayout());
        topPanel.add(leftPanel, BorderLayout.WEST);
        topPanel.add(rightPanel, BorderLayout.EAST);

        headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.add(tablePanel);
        headerPanel.add(topPanel);
        frame.add(headerPanel, BorderLayout.NORTH);

        searchCriteria = new JComboBox<>(new String[]{"ФИО водителя", "Стаж работы", "Класс"});
        searchField = new JTextField(20);
        searchButton = new JButton("Поиск");
        resetButton = new JButton("Показать все записи");

        filterPanel = new JPanel();
        filterPanel.add(new JLabel("Критерий поиска: "));
        filterPanel.add(searchCriteria);
        filterPanel.add(new JLabel("Значение: "));
        filterPanel.add(searchField);
        filterPanel.add(searchButton);
        filterPanel.add(Box.createHorizontalStrut(10));
        filterPanel.add(resetButton);
        frame.add(filterPanel, BorderLayout.SOUTH);

        String[] columns = {"ФИО водителя", "Стаж работы", "Класс"};
        Object[][] data = {};
        tableModel = new DefaultTableModel(data, columns);
        table = new JTable(tableModel);
        scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
        dbDataLoader.loadDrivers();

        DBConnection dbConnection = new DBConnection();
        connection = dbConnection.connect();
        editDriver = new EditDriver(connection);
        addDriver = new AddDriver(connection);
        deleteDriver = new DeleteDriver(connection);
        tableSorter = new TableSorter(connection);
        exportToXML = new ExportToXML(connection);
        importFromXML = new ImportFromXML(connection);

        sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        searchHandler = new TableSearch(frame, table, sorter);

        Listeners();

        frame.setVisible(true);
    }

    private void Listeners() {

        addButton.addActionListener(e -> {
            addDriver.showAddDriver(frame, tableModel);
        });

        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int modelRow = table.convertRowIndexToModel(selectedRow);
                editDriver.show(frame, tableModel, modelRow);
            } else {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите строку для редактирования", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int modelRow = table.convertRowIndexToModel(selectedRow);
                deleteDriver.deleteDriver(modelRow, tableModel);
            } else {
                JOptionPane.showMessageDialog(frame, "Пожалуйста, выберите строку для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        saveButton.addActionListener(e -> {
            exportToXML.export();
        });

        loadButton.addActionListener(e -> {
            importFromXML.importData();
            tableModel.setRowCount(0);
            DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
            dbDataLoader.loadDrivers();
        });

        mainMenu.addActionListener(e -> {
            frame.dispose();
            mainWindow mainWindow = new mainWindow();
            mainWindow.show();
        });

        changeTable.addActionListener(e -> {
            windowSwitcher WindowSwitcher = new windowSwitcher(frame, changeTable, getClass().getSimpleName());
            WindowSwitcher.switchWindow();
        });

        sortAscButton.addActionListener(e -> {
            tableSorter.sortDrivers(tableModel, table, sortCriteria.getSelectedIndex(), true);
            tableModel.setRowCount(0);
            DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
            dbDataLoader.loadDrivers();
        });

        sortDescButton.addActionListener(e -> {
            tableSorter.sortDrivers(tableModel, table, sortCriteria.getSelectedIndex(), false);
            tableModel.setRowCount(0);
            DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
            dbDataLoader.loadDrivers();
        });

        searchButton.addActionListener(e -> {
            try {
                sorter = new TableRowSorter<>(tableModel);
                table.setRowSorter(sorter);
                searchHandler = new TableSearch(frame, table, sorter);

                String searchCriteriaValue = (String) searchCriteria.getSelectedItem();
                String searchValue = searchField.getText();
                searchHandler.driverSearch(searchCriteriaValue, searchValue);
            } catch (EmptySearchFieldException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Ошибка поиска", JOptionPane.ERROR_MESSAGE);
            }
        });

        resetButton.addActionListener(e -> {
            sorter.setRowFilter(null);
        });
    }
}
