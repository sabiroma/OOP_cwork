package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.sql.*;
import java.text.SimpleDateFormat;

public class TableSorter {

    private final Connection connection;

    public TableSorter(Connection connection) {
        this.connection = connection;
    }

    public void sortDrivers(DefaultTableModel tableModel, JTable table, int columnIndex, boolean ascending) {
        String[] columnNames = {"Name", "Experience", "Category"};
        String[] dbColumnNames = {"d.Names", "d.Experience", "d.Category"};

        String orderColumn = dbColumnNames[columnIndex];
        String order = ascending ? "ASC" : "DESC";

        String query = String.format("SELECT d.DriverID, d.Names, d.Experience, d.Category, d.OrderIndex FROM Drivers d ORDER BY %s %s", orderColumn, order);

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);

            String updateQuery = "UPDATE Drivers SET OrderIndex = ? WHERE DriverID = ?";
            PreparedStatement editStmt = connection.prepareStatement(updateQuery);

            int orderIndex = 1;

            while (rs.next()) {
                Object[] rowData = new Object[columnNames.length];

                rowData[0] = rs.getString("Names");
                rowData[1] = rs.getInt("Experience");
                rowData[2] = rs.getString("Category");

                tableModel.addRow(rowData);

                try {
                    editStmt.setInt(1, orderIndex++);
                    editStmt.setInt(2, rs.getInt("DriverID"));
                    editStmt.executeUpdate();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Ошибка при обновлении OrderIndex для DriverID=" + rs.getInt("DriverID") + ": " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка при сортировке данных Drivers: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
    }

    public void sortRoutes(DefaultTableModel tableModel, JTable table, int columnIndex, boolean ascending) {
        String[] columnNames = {"RouteNumber", "StartPoint", "EndPoint", "StartTime", "EndTime", "Interval"};
        String[] dbColumnNames = {"r.RouteNumber", "r.StartPoint", "r.EndPoint", "r.StartTime", "r.EndTime", "r.Interval"};

        String orderColumn = dbColumnNames[columnIndex];
        String order = ascending ? "ASC" : "DESC";

        String query = String.format("SELECT r.RouteID, r.RouteNumber, r.StartPoint, r.EndPoint, r.StartTime, r.EndTime, r.Interval, r.OrderIndex " +
                "FROM Routes r ORDER BY %s %s", orderColumn, order);

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);

            String updateQuery = "UPDATE Routes SET OrderIndex = ? WHERE RouteID = ?";
            PreparedStatement editStmt = connection.prepareStatement(updateQuery);

            int orderIndex = 1;

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            while (rs.next()) {
                Object[] rowData = new Object[columnNames.length];

                rowData[0] = rs.getString("RouteNumber");
                rowData[1] = rs.getString("StartPoint");
                rowData[2] = rs.getString("EndPoint");
                rowData[3] = formatTime(rs.getTime("StartTime"), timeFormat);
                rowData[4] = formatTime(rs.getTime("EndTime"), timeFormat);
                rowData[5] = rs.getString("Interval");

                tableModel.addRow(rowData);

                try {
                    editStmt.setInt(1, orderIndex++);
                    editStmt.setInt(2, rs.getInt("RouteID"));
                    editStmt.executeUpdate();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Ошибка при обновлении OrderIndex для RouteID=" + rs.getInt("RouteID") + ": " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка при сортировке данных Routes: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
    }

    public void sortSchedules(DefaultTableModel tableModel, JTable table, int columnIndex, boolean ascending) {
        String[] columnNames = {"RouteNumber", "DriverName", "BusNumber", "DepartureTime", "ArrivalTime", "ActualDepartureTime", "ActualArrivalTime", "Violations"};

        String[] dbColumnNames = {"r.RouteNumber", "d.Names AS DriverName", "s.BusNumber", "s.DepartureTime", "s.ArrivalTime", "s.ActualDepartureTime", "s.ActualArrivalTime", "s.Violations"};

        String orderColumn = dbColumnNames[columnIndex];
        String order = ascending ? "ASC" : "DESC";

        String query = String.format("SELECT s.ScheduleID, r.RouteNumber, d.Names AS DriverName, s.BusNumber, s.DepartureTime, s.ArrivalTime, s.ActualDepartureTime, s.ActualArrivalTime, s.Violations, s.OrderIndex FROM Schedule s JOIN Routes r ON s.RouteID = r.RouteID JOIN Drivers d ON s.DriverID = d.DriverID ORDER BY %s %s", columnIndex == 1 ? "d.Names" : orderColumn, order);

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);

            String updateQuery = "UPDATE Schedule SET OrderIndex = ? WHERE ScheduleID = ?";
            PreparedStatement editStmt = connection.prepareStatement(updateQuery);

            int orderIndex = 1;

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            while (rs.next()) {
                Object[] rowData = new Object[columnNames.length];
                rowData[0] = rs.getString("RouteNumber");
                rowData[1] = rs.getString("DriverName");
                rowData[2] = rs.getString("BusNumber");
                rowData[3] = formatTime(rs.getTime("DepartureTime"), timeFormat);
                rowData[4] = formatTime(rs.getTime("ArrivalTime"), timeFormat);
                rowData[5] = formatTime(rs.getTime("ActualDepartureTime"), timeFormat);
                rowData[6] = formatTime(rs.getTime("ActualArrivalTime"), timeFormat);
                rowData[7] = rs.getString("Violations");

                tableModel.addRow(rowData);

                editStmt.setInt(1, orderIndex++);
                editStmt.setInt(2, rs.getInt("ScheduleID"));
                editStmt.executeUpdate();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка при сортировке данных Schedule: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
    }

    private String formatTime(java.sql.Time time, SimpleDateFormat timeFormat) {
        return (time != null) ? timeFormat.format(time) : null;
    }
}
