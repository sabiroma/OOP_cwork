package org.sabirov3312_cwork;

public class EmptySearchFieldException extends Exception {
    public EmptySearchFieldException(String message) {
        super(message);
    }
}

