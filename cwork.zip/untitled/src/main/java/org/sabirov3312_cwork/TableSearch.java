package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class TableSearch {

    private final JFrame frame;
    private final JTable table;
    private final TableRowSorter<DefaultTableModel> sorter;

    public TableSearch(JFrame frame, JTable table, TableRowSorter<DefaultTableModel> sorter) {
        this.frame = frame;
        this.table = table;
        this.sorter = sorter;
    }

    public void driverSearch(String searchCriteria, String searchValue) throws EmptySearchFieldException {
        if (searchValue.isEmpty()) {
            throw new EmptySearchFieldException("Поле поиска не должно быть пустым.");
        }

        try {
            int columnIndex = getColumnIndex(searchCriteria, "driver");

            if ("Стаж работы".equals(searchCriteria)) {
                try {
                    Integer.parseInt(searchValue);
                    String regex = "^" + searchValue + "$";
                    RowFilter<DefaultTableModel, Object> rowFilter = RowFilter.regexFilter(regex, columnIndex);
                    sorter.setRowFilter(rowFilter);
                } catch (NumberFormatException ex) {
                    throw new EmptySearchFieldException("Введите корректное число для поиска по стажу.");
                }
            } else {
                String regex = "(?i)" + searchValue.replaceAll("([\\W&&[^\\s]])", "\\\\$1");
                RowFilter<DefaultTableModel, Object> rowFilter = RowFilter.regexFilter(regex, columnIndex);
                sorter.setRowFilter(rowFilter);
            }

            if (table.getRowCount() == 0) {
                sorter.setRowFilter(null);
                JOptionPane.showMessageDialog(frame, "Совпадений не найдено", "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Найдены совпадения по критерию: " + searchCriteria, "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (EmptySearchFieldException ex) {
            throw ex;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Ошибка при поиске: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void routeSearch(String searchCriteria, String searchValue) throws EmptySearchFieldException {
        if (searchValue.isEmpty()) {
            throw new EmptySearchFieldException("Поле поиска не должно быть пустым.");
        }

        try {
            int columnIndex = getColumnIndex(searchCriteria, "route");

            if ("Интервал".equals(searchCriteria)) {
                try {
                    Integer.parseInt(searchValue);
                    String regex = "^" + searchValue + "$";
                    RowFilter<DefaultTableModel, Object> rowFilter = RowFilter.regexFilter(regex, columnIndex);
                    sorter.setRowFilter(rowFilter);
                } catch (NumberFormatException ex) {
                    throw new EmptySearchFieldException("Введите корректное число для поиска.");
                }
            } else {
                String regex = "(?i)" + searchValue.replaceAll("([\\W&&[^\\s]])", "\\\\$1");
                RowFilter<DefaultTableModel, Object> rowFilter = RowFilter.regexFilter(regex, columnIndex);
                sorter.setRowFilter(rowFilter);
            }

            if (table.getRowCount() == 0) {
                sorter.setRowFilter(null);
                JOptionPane.showMessageDialog(frame, "Совпадений не найдено", "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Найдены совпадения по критерию: " + searchCriteria, "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Ошибка при поиске: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getColumnIndex(String searchCriteria, String tableType) {
        if ("driver".equals(tableType)) {
            if ("ФИО водителя".equals(searchCriteria)) {
                return 0;
            }
            if ("Стаж работы".equals(searchCriteria)) {
                return 1;
            }
            if ("Класс".equals(searchCriteria)) {
                return 2;
            }
        }
        if ("route".equals(tableType)) {
            if ("Номер маршрута".equals(searchCriteria)) {
                return 0;
            }
            if ("Начальная остановка".equals(searchCriteria)) {
                return 1;
            }
            if ("Конечная остановка".equals(searchCriteria)) {
                return 2;
            }
            if ("Время начала".equals(searchCriteria)) {
                return 3;
            }
            if ("Время окончания".equals(searchCriteria)) {
                return 4;
            }
            if ("Интервал".equals(searchCriteria)) {
                return 5;
            }
        }
        throw new IllegalArgumentException("Ошибка");
    }

    public void scheduleSearch(String searchCriteria, String searchValue) throws EmptySearchFieldException {
        if (searchValue.isEmpty()) {
            throw new EmptySearchFieldException("Поле поиска не должно быть пустым.");
        }

        try {
            int columnIndex = getColumnIndex(searchCriteria);

            String regex = "(?i)" + searchValue.replaceAll("([\\W&&[^\\s]])", "\\\\$1");
            RowFilter<DefaultTableModel, Object> rowFilter = RowFilter.regexFilter(regex, columnIndex);
            sorter.setRowFilter(rowFilter);

            if (table.getRowCount() == 0) {
                sorter.setRowFilter(null);
                JOptionPane.showMessageDialog(frame, "Совпадений не найдено", "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Найдены совпадения по критерию: " + searchCriteria, "Результат поиска", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Ошибка при поиске: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getColumnIndex(String searchCriteria) {
        if ("Номер маршрута".equals(searchCriteria)) {
            return 0;
        }
        if ("ФИО водителя".equals(searchCriteria)) {
            return 1;
        }
        if ("Номер автобуса".equals(searchCriteria)) {
            return 2;
        }
        if ("Время отправления".equals(searchCriteria)) {
            return 3;
        }
        if ("Время прибытия".equals(searchCriteria)) {
            return 4;
        }
        if ("Факт. время отправления".equals(searchCriteria)) {
            return 5;
        }
        if ("Факт. время прибытия".equals(searchCriteria)) {
            return 6;
        }
        if ("Нарушения".equals(searchCriteria)) {
            return 7;
        }
        throw new IllegalArgumentException("Ошибка");
    }
}
