package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class EditRoute {

    private final Connection connection;

    public EditRoute(Connection connection) {
        this.connection = connection;
    }

    public void show(JFrame frame, DefaultTableModel tableModel, int selectedRow) {
        String selectedRouteNumber = (String) tableModel.getValueAt(selectedRow, 0);
        String selectedStartPoint = (String) tableModel.getValueAt(selectedRow, 1);
        String selectedEndPoint = (String) tableModel.getValueAt(selectedRow, 2);
        String selectedStartTime = (String) tableModel.getValueAt(selectedRow, 3);
        String selectedEndTime = (String) tableModel.getValueAt(selectedRow, 4);
        String selectedInterval = (String) tableModel.getValueAt(selectedRow, 5);

        JPanel panel = new JPanel(new GridLayout(6, 2));

        JTextField routeNumberField = new JTextField(selectedRouteNumber, 20);
        JTextField startPointField = new JTextField(selectedStartPoint, 20);
        JTextField endPointField = new JTextField(selectedEndPoint, 20);
        JTextField startTimeField = new JTextField(selectedStartTime, 20);
        JTextField endTimeField = new JTextField(selectedEndTime, 20);
        JTextField intervalField = new JTextField(selectedInterval, 20);

        panel.add(new JLabel("Номер маршрута: "));
        panel.add(routeNumberField);
        panel.add(new JLabel("Начальная остановка: "));
        panel.add(startPointField);
        panel.add(new JLabel("Конечная остановка: "));
        panel.add(endPointField);
        panel.add(new JLabel("Время начала: "));
        panel.add(startTimeField);
        panel.add(new JLabel("Время окончания: "));
        panel.add(endTimeField);
        panel.add(new JLabel("Интервал: "));
        panel.add(intervalField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Редактировать маршрут", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String newRouteNumber = routeNumberField.getText();
            String newStartPoint = startPointField.getText();
            String newEndPoint = endPointField.getText();
            String newStartTime = startTimeField.getText();
            String newEndTime = endTimeField.getText();
            String newInterval = intervalField.getText();

            try {
                validate(newRouteNumber, newStartPoint, newEndPoint, newStartTime, newEndTime, newInterval);
                edit(selectedRouteNumber, newRouteNumber, newStartPoint, newEndPoint, newStartTime, newEndTime, newInterval);
                loadRoutes(tableModel);
                tableModel.setRowCount(0);
                DBDataLoader dbDataLoader = new DBDataLoader(frame, tableModel);
                dbDataLoader.loadRoutes();
                JOptionPane.showMessageDialog(frame, "Маршрут успешно обновлен!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame, e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void validate(String routeNumber, String startPoint, String endPoint, String startTime, String endTime, String interval) throws ParseException {
        if (routeNumber.isEmpty() || startPoint.isEmpty() || endPoint.isEmpty() || startTime.isEmpty() || endTime.isEmpty() || interval.isEmpty()) {
            throw new IllegalArgumentException("Все поля должны быть заполнены.");
        }

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        timeFormat.parse(startTime.trim());
        timeFormat.parse(endTime.trim());
    }

    private void edit(String oldRouteNumber, String newRouteNumber, String startPoint, String endPoint, String startTime, String endTime, String interval) throws SQLException {
        String query = "UPDATE Routes SET RouteNumber = ?, StartPoint = ?, EndPoint = ?, StartTime = ?, EndTime = ?, Interval = ? WHERE RouteNumber = ?";
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, newRouteNumber);
            stmt.setString(2, startPoint);
            stmt.setString(3, endPoint);
            stmt.setTime(4, new java.sql.Time(timeFormat.parse(startTime).getTime()));
            stmt.setTime(5, new java.sql.Time(timeFormat.parse(endTime).getTime()));
            stmt.setString(6, interval);
            stmt.setString(7, oldRouteNumber);

            stmt.executeUpdate();
        } catch (ParseException e) {
            throw new IllegalArgumentException("Ошибка в формате времени. Используйте HH:mm.");
        }
    }

    public void loadRoutes(DefaultTableModel tableModel) throws SQLException {
        String query = "SELECT RouteNumber, StartPoint, EndPoint, StartTime, EndTime, Interval FROM Routes";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            var rs = stmt.executeQuery();
            tableModel.setRowCount(0);
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getString("RouteNumber"), rs.getString("StartPoint"), rs.getString("EndPoint"), timeFormat.format(rs.getTime("StartTime")), timeFormat.format(rs.getTime("EndTime")), rs.getString("Interval")
                });
            }
        }
    }
}
