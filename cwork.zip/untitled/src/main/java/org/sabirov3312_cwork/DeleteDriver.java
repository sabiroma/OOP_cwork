package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteDriver {

    private final Connection connection;

    public DeleteDriver(Connection connection) {
        this.connection = connection;
    }

    public void deleteDriver(int selectedRow, DefaultTableModel tableModel) {
        String name = (String) tableModel.getValueAt(selectedRow, 0);

        if (has(name)) {
            JOptionPane.showMessageDialog(null, "Невозможно удалить водителя, так как есть записи в расписании с его участием.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int result = JOptionPane.showOptionDialog(null, "Вы точно хотите удалить водителя: " + name + "?", "Подтверждение удаления", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Да", "Нет"}, "Нет");

        if (result == 0) {
            String query = "DELETE FROM Drivers WHERE Names = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, name);
                stmt.executeUpdate();
                tableModel.removeRow(selectedRow);
                JOptionPane.showMessageDialog(null, "Водитель успешно удален!");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ошибка при удалении водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean has(String driverName) {
        String query = "SELECT COUNT(*) AS count FROM Schedule s JOIN Drivers d ON s.DriverID = d.DriverID WHERE d.Names = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, driverName);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при проверке данных расписаний: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
}
