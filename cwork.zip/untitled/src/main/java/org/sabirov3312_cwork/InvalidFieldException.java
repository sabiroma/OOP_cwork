package org.sabirov3312_cwork;

public class InvalidFieldException extends Exception {
    public InvalidFieldException(String message) {
        super(message);
    }
}