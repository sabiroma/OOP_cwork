package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteSchedule {

    private final Connection connection;

    public DeleteSchedule(Connection connection) {
        this.connection = connection;
    }

    public int getDriverID(String driverName) {
        String query = "SELECT DriverID FROM Drivers WHERE Names = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, driverName);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("DriverID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при поиске ID водителя: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return -1;
    }

    public int getRouteID(String routeNumber) {
        String query = "SELECT RouteID FROM Routes WHERE RouteNumber = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, routeNumber);
            var rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("RouteID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при поиске ID маршрута: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
        return -1;
    }

    public void deleteSchedule(int selectedRow, DefaultTableModel tableModel) {
        String routeNumber = (String) tableModel.getValueAt(selectedRow, 0);
        String driverName = (String) tableModel.getValueAt(selectedRow, 1);

        int routeID = getRouteID(routeNumber);
        int driverID = getDriverID(driverName);

        if (routeID == -1 || driverID == -1) {
            JOptionPane.showMessageDialog(null, "Ошибка: не удалось найти ID для маршрута или водителя", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int result = JOptionPane.showOptionDialog(null, "Вы точно хотите удалить запись?", "Подтверждение удаления", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Да", "Нет"}, "Нет");

        if (result == 0) {
            String query = "DELETE FROM Schedule WHERE RouteID = ? AND DriverID = ?";

            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, routeID);
                stmt.setInt(2, driverID);

                stmt.executeUpdate();
                tableModel.removeRow(selectedRow);
                JOptionPane.showMessageDialog(null, "Расписание успешно удалено!");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Ошибка при удалении расписания: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
