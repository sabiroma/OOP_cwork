package org.sabirov3312_cwork;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddRoute {

    private final Connection connection;

    public AddRoute(Connection connection) {
        this.connection = connection;
    }

    public void showAddRoute(JFrame frame, DefaultTableModel tableModel) {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        JTextField routeNumberField = new JTextField(20);
        JTextField startPointField = new JTextField(20);
        JTextField endPointField = new JTextField(20);
        JTextField startTimeField = new JTextField(20);
        JTextField endTimeField = new JTextField(20);
        JTextField intervalField = new JTextField(20);

        panel.add(new JLabel("Номер маршрута: "));
        panel.add(routeNumberField);
        panel.add(new JLabel("Начальная остановка: "));
        panel.add(startPointField);
        panel.add(new JLabel("Конечная остановка: "));
        panel.add(endPointField);
        panel.add(new JLabel("Время начала: "));
        panel.add(startTimeField);
        panel.add(new JLabel("Время окончания: "));
        panel.add(endTimeField);
        panel.add(new JLabel("Интервал: "));
        panel.add(intervalField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Добавить маршрут", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String routeNumber = routeNumberField.getText();
            String startPoint = startPointField.getText();
            String endPoint = endPointField.getText();
            String startTime = startTimeField.getText();
            String endTime = endTimeField.getText();
            String interval = intervalField.getText();

            if (validate(routeNumber, startPoint, endPoint, startTime, endTime, interval)) {
                add(routeNumber, startPoint, endPoint, startTime, endTime, interval);
                loadRoutes(tableModel);
            } else {
                JOptionPane.showMessageDialog(frame, "Ошибка ввода данных", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean validate(String routeNumber, String startPoint, String endPoint, String startTime, String endTime, String interval) {
        return !routeNumber.isEmpty() && !startPoint.isEmpty() && !endPoint.isEmpty() && !startTime.isEmpty() && !endTime.isEmpty() && !interval.isEmpty();
    }

    public void add(String routeNumber, String startPoint, String endPoint, String startTime, String endTime, String interval) {
        String checkQuery = "SELECT COUNT(*) AS count FROM Routes WHERE RouteNumber = ?";
        String maxOrderIndexQuery = "SELECT MAX(OrderIndex) AS maxIndex FROM Routes";
        String insertQuery = "INSERT INTO Routes (RouteNumber, StartPoint, EndPoint, StartTime, EndTime, Interval, OrderIndex) VALUES (?, ?, ?, ?, ?, ?, ?)";

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

        try {
            try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                checkStmt.setString(1, routeNumber);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt("count") > 0) {
                    JOptionPane.showMessageDialog(null, "Ошибка: Маршрут с таким номером уже существует!", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            int newOrderIndex = 1;
            try (PreparedStatement maxOrderStmt = connection.prepareStatement(maxOrderIndexQuery)) {
                ResultSet rs = maxOrderStmt.executeQuery();
                if (rs.next() && rs.getInt("maxIndex") > 0) {
                    newOrderIndex = rs.getInt("maxIndex") + 1;
                }
            }

            Date parsedStartTime = timeFormat.parse(startTime.trim());
            Date parsedEndTime = timeFormat.parse(endTime.trim());

            try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                insertStmt.setString(1, routeNumber);
                insertStmt.setString(2, startPoint);
                insertStmt.setString(3, endPoint);
                insertStmt.setTime(4, new java.sql.Time(parsedStartTime.getTime()));
                insertStmt.setTime(5, new java.sql.Time(parsedEndTime.getTime()));
                insertStmt.setString(6, interval);
                insertStmt.setInt(7, newOrderIndex);
                insertStmt.executeUpdate();

                JOptionPane.showMessageDialog(null, "Маршрут успешно добавлен!");
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Ошибка в формате времени. Используйте HH:mm, например 10:30", "Ошибка", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при добавлении маршрута: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void loadRoutes(DefaultTableModel tableModel) {
        try {
            String query = "SELECT RouteNumber, StartPoint, EndPoint, StartTime, EndTime, Interval, OrderIndex FROM Routes ORDER BY OrderIndex ASC";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

            while (rs.next()) {
                String startTime = timeFormat.format(rs.getTime("StartTime"));
                String endTime = timeFormat.format(rs.getTime("EndTime"));

                tableModel.addRow(new Object[]{rs.getString("RouteNumber"), rs.getString("StartPoint"), rs.getString("EndPoint"), startTime, endTime, rs.getString("Interval"), rs.getInt("OrderIndex")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке данных маршрутов: " + e.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
